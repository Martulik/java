package textMarkup;

import java.util.List;

public class Emphasis extends Markdown {
    Emphasis(List<TextInterface> list) {
        super(list, "*");
    }
}

