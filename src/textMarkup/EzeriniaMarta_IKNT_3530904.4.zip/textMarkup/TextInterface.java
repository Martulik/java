package textMarkup;

public interface TextInterface {
    void toMarkdown(StringBuilder stringBuilder);
}
