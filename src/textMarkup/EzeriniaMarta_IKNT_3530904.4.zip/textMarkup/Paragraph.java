package textMarkup;

import java.util.List;

public class Paragraph extends Markdown {
    Paragraph(List<TextInterface> list) {
        super(list, "");
    }
}

